# Aetherchrome Core

This repository contains the version-controlled rules, registries, campaign material, and governance records for the Aetherchrome tabletop role-playing system.

## Current project state

The canonical-source migration from Google Drive completed on 2026-08-02, moving the
system's Markdown sources and per-tab CSV workbook exports into version control. See the
[migration report](<00 Governance/MIGRATION_REPORT.md>) for that migration's complete
audit, exclusions, and integrity checks.

That CSV baseline was converted to schema-validated YAML, registry by registry — every
registry (Tags, Statuses, Situations, Materials, Services, Items, Traits, Skills, Tasks,
Economy, Campaigns, Feedback, Governance, and the Core Mechanics reference tables) finished
converting and transitioned authority as of 2026-08-03. The conversion tooling itself
(per-registry migrate scripts, CSV-comparison tests) was retired 2026-08-04 as part of the
v0.0.2→v0.0.3 version-boundary cleanup (see git history for the full sequence).
`00 Governance/AEC — Registry Migration Runbook v0.0.2.md` is kept only as historical record
of how that migration was done, not as an active procedure. Implementation work is done
directly rather than through a separate ticket/handoff process — see `AGENTS.md` for the
current editing and validation conventions.

Rules remain a mixture of `ACTIVE`, `ACTIVE WORKING`, `MIXED ACTIVE / PROVISIONAL`, and `PROVISIONAL` material. A file's presence in the repository does not by itself establish authority or finality.

Current Skill Registry additions include the `Fight > Melee > Polearm` branch (`status: active_working`; `provisional` was retired as a registry status repo-wide on 2026-08-06). The Sword and Knife Skill display names are singular; their stable IDs remain `SKL-SWORDS` and `SKL-KNIVES`.

## Versioning

The `v0.0.1` Git tag preserves the completed migration baseline. Current governed Markdown sources use the `v0.0.3` document baseline and three-part release versions. As of the `v0.0.3` baseline, the release version no longer appears in the filename or level-one heading — it lives only in each document's `Version` metadata field and version-record table (see `AEC — Source Standard.md` §6, §15). A handful of historical/point-in-time governance records that predate this rule keep their old `v0.0.2`-suffixed filenames rather than being renamed retroactively.

Working revisions within a document release may append `-rN` to current version metadata and version-record entries. The suffix is cleared when a new release baseline begins and does not appear in the filename. Historical version-record rows and structured registry record versions are preserved independently of the repository release tag.

## Authority workflow

Before answering a rules question or changing an established rule:

1. Consult the [Project Manifest Control Register](<00 Governance/data/control-register.yaml>).
2. Identify and read the subsystem's controlling source.
3. Use the named structured registry for individual record values when the manifest assigns one.
4. Check applicable owner decisions and open-decision records.
5. Report conflicts or missing controlling sources instead of silently reconciling or inventing rules.

The [Source Inventory](<00 Governance/data/source-inventory.yaml>) controls repository routing. The preserved legacy manifest is non-authoritative.

## Repository structure

- `00 Governance/` — source standards, project routing, authority records, migration audit, and structured governance tables.
- `01 Design Principles/` — system-wide design principles.
- `02 Core Mechanics/` — resolution, encounters, combat, Skills, Statuses, and their registries.
- `03 Actor Management/` — Actor Creation, costs, Traits, and the Trait Registry.
- `04 Economy/` — equipment, economics, downtime, materials, items, and services.
- `05 Campaigns/` — Crownshard Realms and OIT campaign sources and the Campaign Registry.
- `07 Publications/` — player-facing publication material and templates.
- `08 Feedback/` — feedback procedures, templates, and structured feedback records.
- `schemas/` — JSON Schema definitions for every converted registry's YAML records.
- `scripts/` — validation and generation tooling (`validate.py`, `generate.py`,
  `new_record.py`, `scaffold_registry.py`). The per-registry CSV→YAML migration scripts
  were retired 2026-08-04 once every registry finished converting.
- `generated/` — CSV/JSON/Markdown views derived from the canonical YAML; never edit
  directly, regenerate from source instead.
- `migration-snapshots/` — superseded CSV packages for registries already converted to
  YAML, retained for provenance.
- `tests/` — the migration/validation test suite (`python -m pytest`).

Legacy empty placeholder directories such as `archive/`, `decisions/`, `playtests/`, and
`proposals/` are intentionally not tracked.

## Workbook snapshots

CSV exports preserve displayed values and tab separation, but they do not preserve all native spreadsheet behavior. Depending on the workbook, lost behavior may include formulas, validation rules, formatting, filters, named ranges, and native hyperlinks.

Each registry directory includes a README describing its live source, exported tabs, known loss risks, and reconstruction requirements. Do not infer missing workbook behavior from CSV values alone.

## Contributing

Repository-wide authority, editing, validation, and Git requirements are defined in [AGENTS.md](AGENTS.md). Make the smallest coherent change, preserve stable IDs and authority declarations, validate references and structured records, and do not edit generated or historical material as though it were current authority.
