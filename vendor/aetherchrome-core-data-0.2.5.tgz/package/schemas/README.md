# Schemas

JSON Schema (Draft 2020-12) definitions for canonical YAML records, per
AEC — Repository Data Architecture Proposal v0.0.2 §18 and §31 Commit 4.

- `common/authority.schema.json` — subsystem and controlling-source routing (§17), shared by every record type.
- `common/provenance.schema.json` — migration history for a CSV-derived record (§24), shared by every record type.
- `tags/tag-collection.schema.json` — envelope for a Tag collection file (`schema_version`, `record_type`, `records` keyed by `TAG-*`).
- `tags/tag-record.schema.json` — a single Tag record body, referencing the two common schemas.

Field values that are directly evidenced in `02 Core Mechanics/Registries/Tag Registry/Tags.csv` (`status`, `applies_to`) are enums; `family` is deliberately left as free text because its CSV values do not match `Validation Lists.csv`'s own Family column, which the proposal already flags as `NOT VERIFIED` (§36). See the `description` fields inside `tags/tag-record.schema.json` for the exact reasoning.

These schemas validate against fixtures (`tests/schema/fixtures/tags/`, run via `python scripts/validate.py --schemas`) and against the full converted Tag registry (`02 Core Mechanics/data/tags/*.yaml`, run via `python scripts/validate.py --yaml`). `02 Core Mechanics/data/tags/*.yaml` is now the record authority for Tags (Control Register, subsystem `SYS-TAG`, as of the Commit 11 transition on 2026-08-02); `02 Core Mechanics/Registries/Tag Registry/Tags.csv` is retained as a migration snapshot. Semantic and cross-record validation (ID uniqueness, source-path existence, name/alias collisions) is implemented in `scripts/semantic.py`, run via `python scripts/validate.py --semantic` (Commit 6).
